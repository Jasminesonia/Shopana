import template1 from '../../assests/template1.jpg'
import template2 from '../../assests/template2.jpeg'
import template3 from '../../assests/template3.jpg'
import template4 from '../../assests/template4.jpg'
import template5 from '../../assests/template5.jpeg'
import template6 from '../../assests/template6.jpeg'
import template7 from '../../assests/template7.jpeg'
import template8 from '../../assests/template8.jpeg'
import template9 from '../../assests/template9.jpg'

const data = [
  {
    id: '1',
    title: 'Enter your product name',
    description: 'Enter your product description',
    imageUrl: '',
    backgroundImage: template1,
    customData: {},
  },
  {
    id: '2',
    title: 'Enter your product name',
    description: 'Enter your product description',
    imageUrl: '',
    backgroundImage: template2,
    customData: {},
  },
  {
    id: '3',
    title: 'Enter your product name',
    description: 'Enter your product description',
    imageUrl: '',
    backgroundImage: template3,
    customData: {},
  },
  {
    id: '4',
    title: 'Enter your product name',
    description: 'Enter your product description',
    imageUrl: '',
    backgroundImage: template4,
    customData: {},
  },
  {
    id: '5',
    title: 'Enter your product name',
    description: 'Enter your product description',
    imageUrl: '',
    backgroundImage: template5,
    customData: {},
  },
  {
    id: '6',
    title: 'Enter your product name',
    description: 'Enter your product description',
    imageUrl: '',
    backgroundImage: template6,
    customData: {},
  },
  {
    id: '7',
    title: 'Enter your product name',
    description: 'Enter your product description',
    imageUrl: '',
    backgroundImage: template7,
    customData: {},
  },
  {
    id: '8',
    title: 'Enter your product name',
    description: 'Enter your product description',
    imageUrl: '',
    backgroundImage: template8,
    customData: {},
  },
  {
    id: '9',
    title: 'Enter your product name',
    description: 'Enter your product description',
    imageUrl: '',
    backgroundImage: template9,
    customData: {},
  },
];

export default data;